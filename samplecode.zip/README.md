# multi-robot_localization
複数のロボットで自己位置推定をしながらフィールドを動き回らせる実験（実習？）用。

基本的な部分は詳解確率ロボティクス（講談社、上田隆一著）のコードを参考にしました（https://github.com/ryuichiueda/LNPR_BOOK_CODES/tree/master）